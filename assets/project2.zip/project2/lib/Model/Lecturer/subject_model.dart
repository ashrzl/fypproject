class Subject {
  final String subjectCode;
  final String subjectName;
  final String group;
  final String classLink;
  final String lecturerName;

  Subject({
    required this.subjectCode,
    required this.subjectName,
    required this.group,
    required this.classLink,
    required this.lecturerName,
  });

  factory Subject.fromFirestore(String subjectCode, Map<String, dynamic> data) {
    return Subject(
      subjectCode: subjectCode,
      subjectName: data['subjectName'] ?? '',
      group: data['group'] ?? '',
      classLink: data['classLink'] ?? '',
      lecturerName: data['lecturerName'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'subjectCode': subjectCode,
      'subjectName': subjectName,
      'group': group,
      'classLink': classLink,
      'lecturerName': lecturerName,
    };
  }
}

