class Lecturer {
  final String lecturer_name;
  final String lecturer_id;
  final String email;
  final String room_numb;
  final String phone_number;

  Lecturer({
    required this.lecturer_name,
    required this.lecturer_id,
    required this.email,
    required this.room_numb,
    required this.phone_number,
  });

  factory Lecturer.fromFirestore(Map<String, dynamic> data) {
    return Lecturer(
      lecturer_name: data['lecturer_name'],
      lecturer_id: data['lecturer_id'],
      email: data['email'],
      room_numb: data['room_numb'],
      phone_number: data['phone_number'],
    );
  }
}
