class Student {
  final String student_name;
  final String student_id;
  final String email;
  final String class_name;
  final String phone_number;

  Student({
    required this.student_name,
    required this.student_id,
    required this.email,
    required this.class_name,
    required this.phone_number,
  });

  factory Student.fromFirestore(Map<String, dynamic> data) {
    return Student(
      student_name: data['student_name'],
      student_id: data['student_id'],
      email: data['email'],
      class_name: data['class_name'],
      phone_number: data['phone_number'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'student_name': student_name,
      'student_id': student_id,
      'email': email,
      'class_name': class_name,
      'phone_number': phone_number,
    };
  }
}



