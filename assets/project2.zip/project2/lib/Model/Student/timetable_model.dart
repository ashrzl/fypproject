class TimetableEntry {
  final String subjectCode;
  final String subjectName;
  final String lecturerName;
  final String startTime;
  final String endTime;
  final String venue;

  TimetableEntry({
    required this.subjectCode,
    required this.subjectName,
    required this.lecturerName,
    required this.startTime,
    required this.endTime,
    required this.venue,
  });
}
