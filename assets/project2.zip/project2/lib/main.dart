import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:project2/homepage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyAsFySC5ZZ575m4Njwjk-rISK9VlAQbu4w",
      appId: "1:101121275449:android:d3bd31b16c5ac93b883fe8",
      messagingSenderId: "101121275449",
      projectId: "project2-d1126",

    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Main Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}