import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SubjectPage extends StatefulWidget {
  @override
  _SubjectPageState createState() => _SubjectPageState();
}

class _SubjectPageState extends State<SubjectPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _subjectNameController = TextEditingController();
  final TextEditingController _subjectCodeController = TextEditingController();
  final TextEditingController _groupController = TextEditingController();
  final TextEditingController _lecturerNameController = TextEditingController();
  final TextEditingController _classLinkController = TextEditingController();

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      // Create a map of the subject details
      Map<String, String> subjectDetails = {
        'subjectName': _subjectNameController.text,
        'subjectCode': _subjectCodeController.text,
        'group': _groupController.text,
        'lecturerName': _lecturerNameController.text,
        'classLink': _classLinkController.text,
      };

      // Store the subject details in Firestore
      await FirebaseFirestore.instance.collection('subjects').add(subjectDetails);

      // Clear the form fields
      _subjectNameController.clear();
      _subjectCodeController.clear();
      _groupController.clear();
      _lecturerNameController.clear();
      _classLinkController.clear();

      // Show a success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Subject details submitted successfully!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text('Subject Page'),
        ),
    body: Padding(
    padding: const EdgeInsets.all(16.0),
    child: Form(
    key: _formKey,
    child: SingleChildScrollView(
    child: Column(
    children: <Widget>[
    TextFormField(
    controller: _subjectNameController,
    decoration: InputDecoration(labelText: 'Subject Name'),
    validator: (value) {
    if (value == null || value.isEmpty) {
    return 'Please enter the subject name';
    }
    return null;
    },
    ),
    SizedBox(height: 16),
    TextFormField(
    controller: _subjectCodeController,
    decoration: InputDecoration(labelText: 'Subject Code'),
    validator: (value) {
    if (value == null || value.isEmpty) {
    return 'Please enter the subject code';
    }
    return null;
    },
    ),
    SizedBox(height: 16),
    TextFormField(
    controller: _groupController,
    decoration: InputDecoration(labelText: 'Group'),
    validator: (value) {
    if (value == null || value.isEmpty) {
    return 'Please enter the group';
    }
    return null;
    },
    ),
    SizedBox(height: 16),
    TextFormField(
    controller: _lecturerNameController,
    decoration: InputDecoration(labelText: 'Lecturer Name'),
    validator: (value) {
    if (value == null || value.isEmpty) {
    return 'Please enter the lecturer name';
    }
    return null;
    },
    ),
    SizedBox(height: 16),
    TextFormField(
    controller: _classLinkController,
    decoration: InputDecoration(labelText: 'Class Link'),
    validator: (value) {
    if (value == null || value.isEmpty) {
    return 'Please enter the class link';
    }
    return null;
    },
    ),
    SizedBox(height: 16),
    ElevatedButton(
    onPressed: _submitForm,
    child: Text('Submit'),
    ),
    ],
    ),
    ),
    )
    )
    );
  }
}
