import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project2/Model/Lecturer/subject_model.dart';

class SubjectHomePage extends StatefulWidget {
  @override
  _SubjectHomePageState createState() => _SubjectHomePageState();
}

class _SubjectHomePageState extends State<SubjectHomePage> {
  final TextEditingController _subjectCodeController = TextEditingController();
  final List<Subject> _subjects = [];

  void _addSubject() async {
    String subjectCode = _subjectCodeController.text;
    if (subjectCode.isEmpty) return;

    try {
      DocumentSnapshot subjectSnapshot = await FirebaseFirestore.instance
          .collection('subjects')
          .doc(subjectCode)
          .get();

      if (subjectSnapshot.exists) {
        Map<String, dynamic> subjectData = subjectSnapshot.data() as Map<String, dynamic>;
        setState(() {
          _subjects.add(Subject.fromFirestore(subjectCode, subjectData));
          _subjectCodeController.clear();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Subject not found!'),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error fetching subject data: $e'),
        ),
      );
    }
  }

  void _deleteSubjects() {
    setState(() {
      _subjects.clear();
    });
  }

  void _confirmSubjects() {
    // Implement your confirm logic here
    print("Subjects confirmed: ${_subjects.map((subject) => subject.toMap()).toList()}");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Class List Generator for ODL'),
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Navigation Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.class_),
              title: Text('Class'),
              onTap: () {
                // Navigate to class page
              },
            ),
            ListTile(
              leading: Icon(Icons.schedule),
              title: Text('Timetable'),
              onTap: () {
                // Navigate to timetable page
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Log Out'),
              onTap: () {
                // Log out functionality
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Text(
              'SUBJECT',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _subjectCodeController,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Enter Subject Code',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addSubject,
              child: Text('ADD'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: _subjects.isNotEmpty
                  ? DataTable(
                columns: const [
                  DataColumn(label: Text('Subject Code')),
                  DataColumn(label: Text('Subject Name')),
                  DataColumn(label: Text('Class')),
                  DataColumn(label: Text('Link')),
                  DataColumn(label: Text('Lecturer')),
                ],
                rows: _subjects
                    .map(
                      (subject) => DataRow(
                    cells: [
                      DataCell(Text(subject.subjectCode)),
                      DataCell(Text(subject.subjectName)),
                      DataCell(Text(subject.group)),
                      DataCell(Text(subject.classLink)),
                      DataCell(Text(subject.lecturerName)),
                    ],
                  ),
                )
                    .toList(),
              )
                  : Center(child: Text('No subjects added')),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _deleteSubjects,
              child: Text('DELETE ALL'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _confirmSubjects,
              child: Text('CONFIRM'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
            ),
          ],
        ),
      ),
    );
  }
}



