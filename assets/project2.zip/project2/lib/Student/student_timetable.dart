// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:project2/Model/Student/timetable_model.dart';
//
// class TimetablePage extends StatefulWidget {
//   final String email;
//
//   TimetablePage({required this.email});
//
//   @override
//   _TimetablePageState createState() => _TimetablePageState();
// }
//
// class _TimetablePageState extends State<TimetablePage> {
//   List<TimetableEntry> timetableEntries = [];
//   bool isLoading = true;
//
//   @override
//   void initState() {
//     super.initState();
//     fetchTimetable();
//   }
//
//   Future<void> fetchTimetable() async {
//     try {
//       QuerySnapshot querySnapshot = await FirebaseFirestore.instance
//           .collection('timetable')
//           .where('email', isEqualTo: widget.email)
//           .get();
//
//       if (querySnapshot.docs.isNotEmpty) {
//         List<TimetableEntry> entries = querySnapshot.docs.map((doc) {
//           var data = doc.data();
//           return TimetableEntry(
//             subjectCode: data['subjectCode'] ?? '',
//             subjectName: data['subjectName'] ?? '',
//             lecturerName: data['lecturerName'] ?? '',
//             startTime: data['startTime'] ?? '',
//             endTime: data['endTime'] ?? '',
//             venue: data['venue'] ?? '',
//           );
//         }).toList();
//
//         setState(() {
//           timetableEntries = entries;
//           isLoading = false;
//         });
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//       }
//     } catch (e) {
//       print('Error fetching timetable: $e');
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Timetable'),
//         backgroundColor: Colors.deepPurple,
//       ),
//       body: isLoading
//           ? Center(child: CircularProgressIndicator())
//           : timetableEntries.isNotEmpty
//           ? ListView.builder(
//         itemCount: timetableEntries.length,
//         itemBuilder: (context, index) {
//           var entry = timetableEntries[index];
//           return Card(
//             margin:
//             EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//             child: ListTile(
//               title: Text(entry.subjectName),
//               subtitle: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text('Subject Code: ${entry.subjectCode}'),
//                   Text('Lecturer: ${entry.lecturerName}'),
//                   Text('Time: ${entry.startTime} - ${entry.endTime}'),
//                   Text('Venue: ${entry.venue}'),
//                 ],
//               ),
//             ),
//           );
//         },
//       )
//           : Center(
//         child: Text('No timetable entries found.'),
//       ),
//     );
//   }
// }

